import 'dart:async';

import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'package:intl/intl.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Raining Matrix Clock',
      theme: ThemeData(),
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  VideoPlayerController _controller;
  Future<void> _initializeVideoPlayerFuture;
  DateTime _dateTime = DateTime.now();
  Timer _timer;
//
  var _white = Colors.white;
  var _black = Colors.black;

  @override
  void initState() {
    super.initState();
    _controller = VideoPlayerController.asset("videos/matrix.mp4");
    _initializeVideoPlayerFuture = _controller.initialize();
    _controller.setLooping(true);
    _controller.setVolume(0.0);
    _updateTime();
    _updateModel();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _updateTime() {
    setState(() {
      _dateTime = DateTime.now();
      // Update once per minute. If you want to update every second, use the
      // following code.
      _timer = Timer(
        Duration(minutes: 1) -
            Duration(seconds: _dateTime.second) -
            Duration(milliseconds: _dateTime.millisecond),
        _updateTime,
      );
    });
  }

  void _updateModel() {
    setState(() {
      // Cause the clock to rebuild when the model changes.
    });
  }


  @override
  Widget build(BuildContext context) {
    final hour = DateFormat('HH').format(_dateTime);
    final minute = DateFormat('mm').format(_dateTime);
    final fontSize = MediaQuery
        .of(context)
        .size
        .width / 4;

    Widget startAnimation() {
      _controller.play();
      return FutureBuilder(
        future: _initializeVideoPlayerFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.done) {
            return Center(
              child: AspectRatio(
                aspectRatio: _controller.value.aspectRatio,
                child: VideoPlayer(_controller),
              ),
            );
          } else {
            return Center(
//              child: CircularProgressIndicator(),
            );
          }
        },
      );
    }

    final clock = Center(
      child: AspectRatio(
        aspectRatio: 5 / 3,
        child: Container(
            decoration: BoxDecoration(
              border: Border.all(
                  width: 2,
                  color: _black
//              color: Theme.of(context),
              ),
            ),
            child: Stack(
              children: <Widget>[
                startAnimation(),
                Center(
                  child: Text('$hour:$minute',
                    style: TextStyle(color: _white, fontSize: fontSize, fontFamily: 'CX',
                        shadows: <Shadow>[
                          Shadow(color: Colors.green,
                              blurRadius: 8,
                              offset: Offset(3, 0)),
                          Shadow(color: Colors.green,
                              blurRadius: 8,
                              offset: Offset(-3, 0)),
                          Shadow(color: _white,
                              blurRadius: 8,
                              offset: Offset(0, -1)),
                          Shadow(color: _white,
                              blurRadius: 8,
                              offset: Offset(0, 1))
                        ]),),
                )
              ],
            )
        ),
      ),
    );
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(canvasColor: _black),
      home: Scaffold(
        body: SafeArea(
          child: clock,
        ),
      ),
    );
  }
}
